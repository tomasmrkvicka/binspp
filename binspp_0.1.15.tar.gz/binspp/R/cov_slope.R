#' Slope of the area
#'
#' Covariate for data trees_N4.
#'
"cov_slope"
