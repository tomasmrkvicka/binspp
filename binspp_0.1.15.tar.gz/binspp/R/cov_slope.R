#' cov_slope
#'
#' Covariate for data trees_N4.
#'
"cov_slope"
