#' Distance to the reservoir
#'
#' Covariate for data trees_N4.
#'
"cov_reserv"
