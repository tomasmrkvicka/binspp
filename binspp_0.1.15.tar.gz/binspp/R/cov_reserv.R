#' cov_reserv
#'
#' Covariate for data trees_N4.
#'
"cov_reserv"
