#' Right horizontal corners for trees_N4 dataset.
#'
#' The vector of right horizontal corners of rectangles forming observation
#'     window for trees_N4 dataset.
#'
"x_right_N4"
