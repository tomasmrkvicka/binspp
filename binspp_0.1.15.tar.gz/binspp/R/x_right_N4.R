#' x_right_N4
#'
#' Vector for data trees_N4.
#'
"x_right_N4"
