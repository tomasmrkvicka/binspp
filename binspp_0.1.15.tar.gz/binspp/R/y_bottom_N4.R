#' Bottom vertical corners for trees_N4 dataset.
#'
#' The vector of bottom vertical corners of rectangles forming observation
#'    window for trees_N4 dataset.
#'
"y_bottom_N4"
