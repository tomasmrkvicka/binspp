#' y_top_N4
#'
#' Vector for data trees_N4.
#'
"y_top_N4"
