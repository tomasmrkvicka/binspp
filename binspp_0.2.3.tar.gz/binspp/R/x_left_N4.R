#' Left horizontal corners for trees_N4 dataset
#'
#' The vector of left horizontal corners of rectangles forming observation
#'    window for trees_N4 dataset.
#'
"x_left_N4"
