#' Distance to the reforestration polygon
#'
#' Covariate for data trees_N4.
#'
"cov_refor"
