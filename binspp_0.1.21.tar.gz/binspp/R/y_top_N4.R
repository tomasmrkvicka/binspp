#' Vertical corners for trees_N4 dataset
#'
#' The vector of top vertical corners of rectangles forming observation
#'   window for trees_N4 dataset.
#'
"y_top_N4"
