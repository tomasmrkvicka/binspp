#' @title binspp Bayesian inference for Neyman-Scott point processes
#'
#' @description Inference for inhomogeneous Neyman-Scott point processes with various inhomogeneities, inference for generalized Thomas process.
#'
#' @details This package introduces the Bayesian MCMC algorithm for inhomogeneous Thomas process with inhomogeneity in cluster centers, in cluster sizes, cluster spread and in combinations of these inhomogeneities.
#'    This package also introduces the Bayesian MCMC algorithm for generalized Thomas process, allowing cluster size to have a variance that is greater or less than the expected value (cluster sizes are over- or under-dispersed).
#'
#' @docType package
#' @name binspp
#' @author Tomas Mrkvicka <mrkvicka.toma@gmail.com> (author), Jiri Dvorak <dvorak@karlin.mff.cuni.cz> (author), Ladislav Beranek <beranek@jcu.cz> (maintainer), Radim Remes <inrem@jcu.cz> (maintainer)
#'
## #' @useDynLib binspp
#' @useDynLib binspp, .registration=TRUE
## #' @import Rcpp VGAM spatstat nlme FNN cluster mvtnorm
#' @importFrom spatstat.core ppm rpoispp rpoint
#' @importFrom spatstat.geom owin ppp
#' @importFrom mvtnorm rmvnorm
#' @note
#'     LinkingTo: Rcpp, RcppArmadillo, RcppEigen,
#'                VGAM spatstat FNN cluster mvtnorm nlme
#'     License: GPL-3
#'     Encoding: UTF-8
#'
NULL
