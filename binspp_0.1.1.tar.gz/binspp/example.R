require( binspp )

# True parameters
lambda= -.5
theta = 10
kappa = 50
omega = .01

# Hyperpriors
a_kappa = 1.5; b_kappa = .02
a_omega = 2; b_omega = 50
a_theta = 2.5; b_theta = .25
l_lambda <- -1; u_lambda <- .99


# Simulates a pattern with the true parameters
# and runs the mcmc. Also writes to the path specified.
fit <- binspp_wrap(kappa = kappa,
                 omega = omega,
                 lambda = lambda,
                 theta = theta,
                 iter = 1e3,
                 a_kappa = a_kappa,
                 b_kappa = b_kappa,
                 a_omega = a_omega,
                 b_omega = b_omega,
                 l_lambda = l_lambda,
                 u_lambda = u_lambda,
                 a_theta = a_theta,
                 b_theta = b_theta,
                 filename = "./"
                 )
