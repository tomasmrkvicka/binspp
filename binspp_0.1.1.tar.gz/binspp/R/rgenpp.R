# rgenpp <- function( kappa = NULL, scale, lambda, theta, win, nsim = 1, expand = 4*scale, C = NULL, marks = F, cdf_tmp = NULL ){
#
#   if( !is.null( C )){
#     nsim <- length( C )
#   }
#
#   if( is.null( C )){
#     Cwin <- boundingbox(expand.owin(win, distance = expand ))
#     C <- rpoispp( kappa, win = Cwin, nsim = nsim, drop = F )
#   }
#
#   C <- C[sapply( C, getElement, 'n')>0]
#   Cwin <- C[[1]]$win
#   N_daught <- lapply( C, function(x) rgenpois( x$n, lambda, theta, cdf_tmp = cdf_tmp) )
#   daught <- lapply( 1:length( C ), function( k ) do.call( rbind, lapply( 1:length( N_daught[[k]] ), function(z) cbind( rnorm(N_daught[[k]][z],C[[k]]$x[z],scale),rnorm(N_daught[[k]][z],C[[k]]$y[z],scale ) ) ) ))
#   P <- list()
#   for( i in 1:length( C )){
#     P[[i]] <- rep( 1:C[[i]]$n, N_daught[[i]])
#     P[[i]] <- P[[i]][which( (daught[[i]][,1]>=win$xrange[1])&(daught[[i]][,1]<=win$xrange[2])&
#                               (daught[[i]][,2]>=win$yrange[1])&(daught[[i]][,2]<=win$yrange[2]) )]
#   }
#
#   daught <- lapply( daught, as.ppp, W = win)
#   daught <- lapply( daught, function(x) {attr( x,'rejects') <- NULL; x} )
#
#   daught <- lapply( 1:length( daught), function(k) list( x = daught[[k]]$x, y = daught[[k]]$y, P = P[[k]], xrange = win$xrange, yrange = win$yrange))
#   parent <- lapply( 1:length( C), function(k) list( x = C[[k]]$x, y = C[[k]]$y, D = N_daught[[k]], xrange = Cwin$xrange, yrange = Cwin$yrange))
#
#   if( nsim == 1){
#     daught <- daught[[1]]
#     parent <- parent[[1]]
#   }
#   list( X = daught, C = parent)
#
# }


#' RGENPP
#' @description Generation of centers and connections.
#' @param kappa: parameter mcmc
#' @param scale: window scale
#' @param lambda parameter mcmc
#' @param theta:parameter mcmc
#' @param win: the window of the process
#' @param nsim: number of simulations
#' @param expand: initial center 
#' @param C: centers and connections
#' @param marks: show marks (default don't show - FALSE)
#' @param cdf_tmp: the upper limit of the distribution (default no limit)
#'
#' @return
#' @export
#'
#' @examples
rgenpp <- function( kappa = NULL, scale, lambda, theta, win, nsim = 1, expand = 4*scale, C = NULL, marks = FALSE, cdf_tmp = NULL ){

  if( !is.null( C )){
    nsim <- length( C )
  }

  if( is.null( C )){
    winar <- (diff( win$xrange) + 2*expand)*(diff( win$yrange ) +2*expand)
    # Cwin <- boundingbox(expand.owin(win, distance = expand ))
    Nc <- rpois( nsim, kappa*winar )
    # C <- rpoispp( kappa, win = Cwin, nsim = nsim, drop = F )
    C <- lapply( 1:nsim, function(x) cbind( runif( Nc[x], win$xrange[1]-expand, win$xrange[2] + expand),
                runif( Nc[x], win$yrange[1]-expand, win$yrange[2] + expand) ) )
  }

  C <- C[Nc>0]
  Nc <- Nc[Nc>0]
  Cwin <- list( xrange = win$xrange + c(-1,1)*expand, yrange = win$yrange + c(-1,1)*expand)
  N_daught <- lapply( Nc, function(x) rgenpois( x, lambda, theta, cdf_tmp = cdf_tmp) )
  if( any( sapply( N_daught, length) == 0 ) ){browser()}
  daught <- lapply( 1:length( C ), function( k ) do.call( rbind, lapply( 1:length( N_daught[[k]] ),
                                                                         function(z) cbind( rnorm(N_daught[[k]][z],C[[k]][z,1],scale),
                                                                                            rnorm(N_daught[[k]][z],C[[k]][z,2],scale ) ) ) ))
  P <- list()
  for( i in 1:length( C )){
    P[[i]] <- rep( 1:Nc[i], N_daught[[i]])
    P[[i]] <- P[[i]][which( (daught[[i]][,1]>=win$xrange[1])&(daught[[i]][,1]<=win$xrange[2])&
                              (daught[[i]][,2]>=win$yrange[1])&(daught[[i]][,2]<=win$yrange[2]) )]
  }

  # daught <- lapply( daught, as.ppp, W = win)
  # daught <- lapply( daught, function(x) {attr( x,'rejects') <- NULL; x} )
  daught <- lapply( daught, inwin, win = win )

  if( any( sapply( daught, function(x) length(dim(x)))<2)){browser()}

  daught <- lapply( 1:length( daught), function(k) list( x = daught[[k]][,1], y = daught[[k]][,2], P = P[[k]], xrange = win$xrange, yrange = win$yrange))
  parent <- lapply( 1:length( C), function(k) list( x = C[[k]][,1], y = C[[k]][,2], D = N_daught[[k]], xrange = Cwin$xrange, yrange = Cwin$yrange))

  if( nsim == 1){
    daught <- daught[[1]]
    parent <- parent[[1]]
  }
  list( X = daught, C = parent)

}

inwin <- function( X, win ){

 X <- matrix( X[ (X[,1]>=win$xrange[1])&((X[,1]<=win$xrange[2]))&
           (X[,2]>=win$yrange[1])&((X[,2]<=win$yrange[2])), ], ncol = 2)

 X

}

