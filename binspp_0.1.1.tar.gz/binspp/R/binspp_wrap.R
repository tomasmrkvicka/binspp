#' BINSPP_WRAP
#'
#' @description Wrapper for MCMC_FUNC function.
#' @param kappa: true parameter for kappa
#' @param omega: true parameter for omega 
#' @param lambda: true parameter for lambda
#' @param theta: true parameter for theta
#' @param iter: number of iterations
#' @param a_kappa: expected value (mean) of the kappa natural logarithm for log-normal distribution
#' @param b_kappa: standard deviation of the kappa natural logarithm for log-normal distribution
#' @param a_omega: expected value (mean) of the omega natural logarithm for log-normal distribution
#' @param b_omega: standard deviation of the omega natural logarithm for log-normal distribution
#' @param l_lambda: the lowest value of lambda (uniform distribution) 
#' @param u_lambda: the upper value of lambda (uniform distribution)
#' @param a_theta: expected value (mean) of the theta natural logarithm for log-normal distribution
#' @param b_theta: standard deviation of the theta natural logarithm for log-normal distribution
#' @param filename: the name of the output file
#'
#' @return The output is a RDS file with calculated values with the specified name.
#' @export
#'
#' @examples
#' fit <- binspp_wrap(
#' kappa = -.5,
#' omega = .01,
#' lambda = -.5,
#' theta = 10,
#' iter = 1e3,
#' a_kappa = 1.5,
#' b_kappa = .02,
#' a_omega = 2,
#' b_omega = 50,
#' l_lambda = -1,
#' u_lambda = .99,
#' a_theta = 2.5,
#' b_theta = .25,
#' filename = "./"
#' )
#' 
binspp_wrap <- function( kappa, omega, lambda, theta, iter,
                       a_kappa, b_kappa,
                       a_omega, b_omega,
                       l_lambda, u_lambda,
                       a_theta, b_theta,
                       filename = NULL
                       ){

  if( is.null(filename) ){print( warnings( "Filename is not specified!"))}
  tmp <- rgenpp(kappa= kappa, scale =omega, lambda = lambda, theta = theta, win = owin())
  tmp$C$D <- sapply( 1:length( tmp$C$x ), function(x) sum( tmp$X$P == x) )
  el <- system.time( fit <- binspp::mcmc_func_cpp(X = tmp$X, 
                                                  #  kappa0 = 2*kappa, omega0 = 2*omega,
                                                  #  lambda0 = 0, theta0 = theta/2, 
                                                    skappa = .1,somega = .1,
                                                    dlambda = .1,stheta = .1, smove = 4*omega,
                                                    iter = iter, plot.step = 1e9, save.step = 1e9,
                                                    C.step = 1e4, n_upd = 100, n_bdm = 100, filename = "",
                                                    a_kappa = a_kappa, b_kappa = b_kappa,
                                                    a_omega = a_omega, b_omega = b_omega,
                                                    l_lambda = l_lambda, u_lambda = u_lambda,
                                                    a_theta = a_theta, b_theta = b_theta) )

  out <- list( true_pars = list( kappa = kappa, omega = omega, lambda = lambda, theta = theta ),
               true_pat = tmp,
               time = el,
               fit = fit,
               priors = list( a_kappa= a_kappa, b_kappa= b_kappa,
                              a_omega = a_omega, b_omega = b_omega,
                              l_lambda = l_lambda, u_lambda = u_lambda,
                              a_theta = a_theta, b_theta = b_theta))

  lstr <- 10*lambda
  if( lambda < 0){ lstr <- paste0( "minus", 10*abs(lambda)) }

  filename = paste0( filename, kappa, "omega", 1000*omega, "lambda", lstr, "theta", theta, ".rds" )
  saveRDS( out, filename )

  out

}
