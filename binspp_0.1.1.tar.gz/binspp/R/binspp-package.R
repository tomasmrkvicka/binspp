#' binspp: Bayesian inference for Neyman-Scott point processes
#' 
#' Calculation of estimation for a simulated pattern.
#' 
#' @docType package
#' @name binspp
#' @description This package introduces minimal contrast methods and the Bayesian MCMC algorithm for generalizing the Thomas process, allowing cluster size to have a variance that is greater
#'     or less than the expected value (cluster size are over- or under-scattered).
#' @author Tomas Mrkvicka <mrkvicka@jcu.cz> (author), Ladislav Beranek <beranek@jcu.cz> (maintainer), Radim Remes <inrem@jcu.cz> (maintainer)
#' 
#' @import Rcpp VGAM spatstat FNN cluster
#' @note 
#'     LinkingTo: Rcpp,RcppArmadillo, RcppEigen
#'     License: GPL-3
#'     Encoding: UTF-8
#' @useDynLib binspp
NULL