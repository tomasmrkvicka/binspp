#' x_right_N4
#'
#' Data trees_N4 from ...
#'
"x_right_N4"
