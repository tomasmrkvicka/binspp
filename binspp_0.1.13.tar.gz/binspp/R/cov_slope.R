#' cov_slope
#'
#' Data trees_N4 from ...
#'
"cov_slope"
