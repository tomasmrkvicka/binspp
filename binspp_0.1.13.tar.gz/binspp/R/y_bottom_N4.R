#' y_bottom_N4
#'
#' Data trees_N4 from ...
#'
"y_bottom_N4"
