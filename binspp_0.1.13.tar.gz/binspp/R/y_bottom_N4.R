#' y_bottom_N4
#'
#' Vector for data trees_N4.
#'
"y_bottom_N4"
