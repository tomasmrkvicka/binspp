#' x_left_N4
#'
#' Data trees_N4 from ...
#'
"x_left_N4"
