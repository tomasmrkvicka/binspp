#' x_left_N4
#'
#' Vector for data trees_N4.
#'
"x_left_N4"
