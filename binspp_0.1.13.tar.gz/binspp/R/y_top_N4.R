#' y_top_N4
#'
#' Data trees_N4 from ...
#'
"y_top_N4"
