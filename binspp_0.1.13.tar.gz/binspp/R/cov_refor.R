#' cov_refor
#'
#' Covariate for data trees_N4.
#'
"cov_refor"
