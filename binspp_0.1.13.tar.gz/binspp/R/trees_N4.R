#' Trees N4 data
#'
#' A dataset containing trees N4
#' and other variables.
#'
"trees_N4"
