#' cov_tdensity
#'
#' Data trees_N4 from ...
#'
"cov_tdensity"
