#' @title Trees N4 data
#'
#' @description A dataset containing trees N4
#' and other variables.
#'
#' @details Details for dataset
#'
#' @docType data
#'
#' @format A data frame with trees_N4 (list):
#' \describe{
#'   \item{windows}{List of 5}
#'   \item{n}{number of elements}
#'   \item{x}{x coordinates}
#'   \item{y}{y coordinates}
#' }
#' @source \url{http://www.source-to-dataset.com/}
NULL

#' Trees N4 data with all trees
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; ## see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"trees_N4"

#' cov.refor
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"cov.refor"

#' cov.reserv
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"cov.reserv"

#' cov.slope
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"cov.slope"

#' cov.tdensity
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"cov.tdensity"

#' cov.tmi
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"cov.tmi"

#' x_left_N4
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"x_left_N4"

#' x_right_N4
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"x_right_N4"

#' y_bottom_N4
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"y_bottom_N4"

#' y_top_N4
#'
#' Data from ...
#'
#' @docType data
#'
#' @usage data(datasetN4)
#'
## #' @format An object of class \code{"cross"}; see \code{\link[list]{read.cross}}.
#'
#' @keywords datasets
#'
#' @references Moore et al. (2013) Genetics 195:1077-1086
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/23979570}{PubMed})
#'
#' @source \href{https://phenome.jax.org/projects/Moore1b}{QTL Archive}
#'
#' ##@examples
#' ##data(datasetN4)
#' ##treesN4 <- attr(grav, "treesN4")
#' ###phe <- grav$pheno
## #' ##\donttest{iplotCurves(phe, times)}
"y_top_N4"

##
